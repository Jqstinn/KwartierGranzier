export const config = {
    API_HOST: "https://craftmendserver.eu:1970"
};
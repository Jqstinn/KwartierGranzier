# based on react boiler plate because im lazy
https://github.com/react-boilerplate/react-boilerplate
